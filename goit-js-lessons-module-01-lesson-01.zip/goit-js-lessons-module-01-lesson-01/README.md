# GoIT JavaScript Lessons Summary

## Module 1 Lesson 1 (Variables and Types)

- JavaScript Fundamentals
- Adding Script
- Dev Tools
- Syntax Basics
- Variable and Types
- User Input
- Basic Operators
- Numbers
- Strings
- Logical Operators

### JS Tasks:

- Example 1 - Mathematical operators
- Example 2 - Combined operators
- Example 3 - Operators Priority
- Example 4 - Math class
- Example 5 - Template lines
- Example 6 - String methods and chaining
- Example 7 - Comparison operators and type casting
- Example 8 - Logical operators
- Example 9 - Default value and null merge operator
- Example 10 - The % Operator and String Methods
