/* 
Example 1 - Mathematical operators

Display the total number of apples and grapes on the screen. The difference between apples and grapes.

const apples = 47;
const grapes = 135;
const total = ;
console.log(total)
const diff = ;
console.log(diff)
*/

const apples = 47;
const grapes = 135;

const total = apples + grapes;
console.log(total);

const diff = apples - grapes;
console.log(diff);
