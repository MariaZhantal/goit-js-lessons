/* 
Example 2 - Combined operators

Replace the override expression with the combined operator +=.

let students = 100;
students = students + 50;
console.log(students);
*/

let students = 150;
// students = students + 50;
students += 50;
console.log(students);
